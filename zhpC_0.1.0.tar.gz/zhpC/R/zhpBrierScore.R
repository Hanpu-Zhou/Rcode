#Brier Score 我们的方法
#G.t(time,status,299)  #指定时间点关于删失的生存函数

#' To get my Brier Score
#'
#' @param time the survival time
#' @param status the survival status 0 for the censoring; 1 for the event
#' @param pre_sp the prediction of survival probability
#' @param t_star  A numeric of time that you want to compute the brier score at
#'
#' @return A numeric for the brier score
#' @export
#' @examples
#' set.seed(123)
#' time = rnorm(100,300,10)
#' status = sample(c(0,1),100,replace = T)
#' presurp = runif(100,0,1)
#' mybrier(time,status,presurp,350)
#'
#'
#'

mybrier <- function(time,status,pre_sp,t_star){
  #1 定义一个G()基于已有的数据，可以输出给定时间点的删失生存函数取值
  G.t <- function(time,status,my.t){
    library(survminer)
    library(survival)
    #假设给的状态都是0-1
    status0 = ifelse(status==min(status),1,0)  #0变1同时 1变0
    #0 先整一个计算G.t的函数
    #0.1 先用传进来的数据拟合一个survfit以备不时之需
    myfit = survfit(Surv(time,status0)~1)
    res.sum = surv_summary(myfit)  #历险、死亡、删失人数都有统计
    myG.t = res.sum[which(res.sum$time == my.t),]$surv
    #只能指定已有的观测时间点输出他们对应的生存函数取值#输出对应时间点删失的生存概率

    #0.2 如果对应my.t 不是已有的事件时间点 则如下判断用其前后两个点加权得到
    if(length(myG.t) == 0){  #令为前后不为0的生存概率平均
      index1 = max(which(res.sum$time < t_star)) #t*前后两个值的下标
      index2 = min(which(res.sum$time > t_star)) #大于t*中最小的 小于t*中最大的
      G_temp = res.sum$surv #生存概率先提取出来
      myG.t = ((time[index2]-t_star)*G_temp[index1]+(t_star-time[index1])*G_temp[index2])/(time[index2]-time[index1])
      #按照跟两个点的距离 加权计算非事件点的生存概率
    }
    return(myG.t)
  }
  #2 定义函数计算指定时间的BS(t_star)
  sum_before_t = 0
  sum_after_t = 0

  for(i in c(1:length(time))) {
    #1 样本处于t*之前且非删失
    if(time[i] < t_star & status[i] == 1)
    {
      sum_before_t = sum_before_t + 1/G.t(time,status,time[i])*(pre_sp[i])^2
      #最优预测是0所以直接概率平方 前面乘以对应权重,删失生存函数定义为G.t
    }

    #2 样本处于t*之后无论是否删失
    if(time[i] >= t_star){
      sum_after_t = sum_after_t + 1/G.t(time,status,t_star)*(1-pre_sp[i])^2
      #最优预测是1 所以用1减去预测概率平方后 再加上一个权重
    }
  }

  mbs =(sum_before_t + sum_after_t)/length(time)
  return(mbs)

}

#mybrier(mydata$time,mydata$status,mydata$pre_sp,t_star = 299)
#mybrier(mydata$time,mydata$status,mydata$pre_sp,t_star = 300)




