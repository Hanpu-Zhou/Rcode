#'To compute a C-index
#'
#' @param time_status_Sprob A data.frame that contians the survival-time
#'    the status and the survival-probability respectively
#'
#' @return A vector contains the Cindex and the permission counts
#'
#' @export
#'
#' @examples
#'
#' time_status_Sprob = data.frame("time" = c(1,1,2,2,2,2,2,2),
#' "status" = c(0,1,1,0,1,1,0,1),
#' "Sprob" = c(2,3,3,3,4,2,4,3))
#' myC_index(time_status_Sprob)
myC_index <- function(time_status_Sprob){ #数据框三列,time status Sprob 生存时间生存状态 存活概率
  names(time_status_Sprob) <- c("time","status","Sprob")
  permissible = 0   #可比较的样本对数量 最后的分母
  cond = 0          #满足一致性的得分总和  每次加1
  uncond = 0        #不满足一致性的得分总和  每次加0.5
  #  with()
  attach(time_status_Sprob)
  n = nrow(time_status_Sprob)    #每行都表示一个样本
  for (i in 1:(n-1)) {                #注意下标 i只能从1到n-1  对应的j只能从i+1到n
    for (j in (i+1):n) {              #不然不仅是运算量的增加，也会导致分母计数次数过多错误
      #1、先遍历所有样本组合方式，从中筛选出可以比较的样本对
      #1.1 生存时间较小者为删失的，较小分为两种情况 i小或者j小
      if((time[i]<time[j] & status[i]==0) | (time[j]<time[i] & status[j]==0))
        next
      #1.2 生存时间相等且两者均为删失应当被剔除  不能与上面的合并<= 因为可能会包含仅有一个删失但也被剔除
      if(time[i] == time[j] & status[i] == 0 & status[j] == 0)
        next

      #2、剩下的样本对就是可以比较大小的了
      permissible = permissible + 1 #首先可比较样本对数的计数加一

      #2.1、生存时间不等且较小者生存概率也小
      if(time[i] != time[j]){   #首先判断生存时间是否相等是大前提 否则所有其他的都会加0.5了
        if((time[i]<time[j] & Sprob[i] < Sprob[j]) | (time[j]<time[i] & Sprob[j] < Sprob[i]))
        {cond = cond + 1          #满足一致性
        }else if(status[i]==1 & status[j]==1 & Sprob[i]==Sprob[j]){  #均非删失且生存时间不等但预测的相等
          next  #不加直接下一轮
          ##################################################         #uncond = uncond +0.5  #预测结果持平 加0.5
        }

      }

      #2.2、生存时间相等 两者均为非删失
      if(time[i] == time[j] & status[i] == 1 & status[j] == 1){

        if(Sprob[i] == Sprob[j])  #同一时间死亡，生存概率也相等 满足一致性
        {cond = cond + 1
        }else uncond = uncond +0.5
      }

      #2.3、生存时间相等 且仅有一个样本删失 另一个非删失
      if(time[i] == time[j] & ((status[i] == 1 & status[j] == 0) | (status[i] == 0 & status[j] == 1))){
        if((status[i] == 1 & Sprob[i] < Sprob[j]) | (status[j] == 1 & Sprob[j] < Sprob[i])){
          cond = cond + 1      #
        }else if(Sprob[i] == Sprob[j]){  #仅仅预测相等记为0.5 其他(等生存时间时 删失的预测反而先死)不计数
          uncond = uncond +0.5
        }

      }
    }
  }
  C_index = round((cond + uncond)/permissible,3)

  return(c(paste("C-index = ",C_index),paste("permissible = ",permissible),
           paste("uncond = ",uncond),paste("cond = ",cond)))

}
